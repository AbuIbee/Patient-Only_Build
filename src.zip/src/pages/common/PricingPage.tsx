import { useState } from 'react';
import { Check, Star, Lock, RefreshCw, ShieldCheck, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { TIERS, type TierName } from '@/types/subscription';
import { useSubscription } from '@/store/SubscriptionContext';

interface PricingPageProps {
  /** If true, shown as a modal on top of the app (upgrade flow). */
  modal?: boolean;
  onClose?: () => void;
  /** Pre-select a tier when opened from a feature gate. */
  preselectedTier?: TierName;
}

export default function PricingPage({ modal, onClose, preselectedTier }: PricingPageProps) {
  const { subscription, tier: currentTier, trialDays, canRefund } = useSubscription();
  const [selectedTier, setSelectedTier] = useState<TierName>(preselectedTier ?? 'daily_care');
  const [billingAnnual, setBillingAnnual] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSelectTier = async (tierName: TierName) => {
    if (tierName === 'companion') {
      // Free tier — just confirm
      setSelectedTier('companion');
      return;
    }

    setSelectedTier(tierName);
    setIsLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('Please sign in first.');
        return;
      }

      const tierConfig = TIERS[tierName];
      const priceId = billingAnnual && tierConfig.stripePriceIdAnnual
        ? tierConfig.stripePriceIdAnnual
        : tierConfig.stripePriceIdMonthly;

      if (!priceId) {
        toast.error('Pricing configuration error. Please contact support.');
        return;
      }

      // Call your Supabase Edge Function which creates a Stripe Checkout session
      const { data, error } = await supabase.functions.invoke('create-checkout-session', {
        body: {
          priceId,
          tierName,
          userId:   user.id,
          email:    user.email,
          // Pass trial info so Stripe knows this is a trial conversion
          trialEnd: subscription?.trialEndsAt,
        },
      });

      if (error || !data?.url) {
        console.error('[Pricing] Checkout error:', error);
        toast.error('Could not start checkout. Please try again.');
        return;
      }

      // Redirect to Stripe Checkout
      window.location.href = data.url;
    } catch (err) {
      console.error('[Pricing] Unexpected error:', err);
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRequestRefund = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.functions.invoke('request-refund', {
        body: { userId: user.id, subscriptionId: subscription?.stripeSubscriptionId },
      });

      if (error) {
        toast.error('Could not submit refund request. Please email support@memoriahelps.com');
        return;
      }

      toast.success('Refund request submitted! You will hear back within 1 business day.');
    } catch {
      toast.error('Please email support@memoriahelps.com for your refund.');
    }
  };

  const tierOrder: TierName[] = ['companion', 'daily_care', 'full_support'];

  const content = (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-charcoal mb-2">
          Choose Your Plan
        </h1>
        <p className="text-medium-gray">
          Start free — your first week on any paid plan is always free.
        </p>

        {/* Trial / refund banners */}
        {subscription?.status === 'trialing' && trialDays > 0 && (
          <div className="mt-4 inline-flex items-center gap-2 bg-soft-sage/20 border border-soft-sage/30 text-soft-sage rounded-full px-4 py-2 text-sm font-medium">
            <ShieldCheck className="w-4 h-4" />
            {trialDays} day{trialDays !== 1 ? 's' : ''} left in your free trial
          </div>
        )}

        {canRefund && subscription?.status !== 'trialing' && (
          <div className="mt-4 inline-flex items-center gap-2 bg-calm-blue/10 border border-calm-blue/20 text-calm-blue rounded-full px-4 py-2 text-sm font-medium">
            <RefreshCw className="w-4 h-4" />
            You are within the 7-day money-back guarantee window
            <button
              onClick={handleRequestRefund}
              className="underline hover:no-underline ml-1"
            >
              Request refund
            </button>
          </div>
        )}
      </div>

      {/* Annual toggle (only relevant for Full Support) */}
      <div className="flex items-center justify-center gap-3 mb-8">
        <span className={`text-sm font-medium ${!billingAnnual ? 'text-charcoal' : 'text-medium-gray'}`}>
          Monthly
        </span>
        <button
          onClick={() => setBillingAnnual(!billingAnnual)}
          className={`relative w-12 h-6 rounded-full transition-colors ${billingAnnual ? 'bg-warm-bronze' : 'bg-soft-taupe'}`}
        >
          <span
            className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${billingAnnual ? 'translate-x-6' : ''}`}
          />
        </button>
        <span className={`text-sm font-medium ${billingAnnual ? 'text-charcoal' : 'text-medium-gray'}`}>
          Annual
          <span className="ml-1 text-xs bg-soft-sage/20 text-soft-sage px-2 py-0.5 rounded-full">
            Save 33%
          </span>
        </span>
      </div>

      {/* Tier cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {tierOrder.map((tierName, i) => {
          const cfg = TIERS[tierName];
          const isCurrent = currentTier === tierName;
          const isSelected = selectedTier === tierName;
          const isPopular = tierName === 'daily_care';
          const displayPrice = billingAnnual && cfg.annualPrice
            ? (cfg.annualPrice / 12).toFixed(2)
            : cfg.price.toFixed(2);

          return (
            <motion.div
              key={tierName}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className={`relative rounded-2xl border-2 p-6 flex flex-col transition-all ${
                isPopular
                  ? 'border-warm-bronze shadow-elevated'
                  : isSelected
                  ? 'border-calm-blue'
                  : 'border-soft-taupe'
              }`}
            >
              {isPopular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-warm-bronze text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3" />
                    Most Popular
                  </span>
                </div>
              )}

              {isCurrent && (
                <div className="absolute -top-3 right-4">
                  <span className="bg-soft-sage text-white text-xs font-bold px-3 py-1 rounded-full">
                    Your Plan
                  </span>
                </div>
              )}

              <div className="mb-4">
                <h3 className="text-xl font-bold text-charcoal">{cfg.label}</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  {cfg.price === 0 ? (
                    <span className="text-3xl font-bold text-charcoal">Free</span>
                  ) : (
                    <>
                      <span className="text-3xl font-bold text-charcoal">${displayPrice}</span>
                      <span className="text-medium-gray text-sm">/mo</span>
                    </>
                  )}
                </div>
                {billingAnnual && cfg.annualPrice && (
                  <p className="text-xs text-soft-sage mt-0.5">
                    Billed as ${cfg.annualPrice}/yr
                  </p>
                )}
                <p className="text-sm text-medium-gray mt-1">{cfg.tagline}</p>
              </div>

              {/* Feature list */}
              <ul className="space-y-2 flex-1 mb-6">
                {cfg.features.map((feat) => (
                  <li key={feat.label} className="flex items-start gap-2">
                    {feat.included ? (
                      <Check
                        className={`w-4 h-4 mt-0.5 flex-shrink-0 ${feat.highlight ? 'text-warm-bronze' : 'text-soft-sage'}`}
                      />
                    ) : (
                      <Lock className="w-4 h-4 mt-0.5 flex-shrink-0 text-soft-taupe" />
                    )}
                    <span
                      className={`text-sm ${feat.included ? (feat.highlight ? 'text-charcoal font-medium' : 'text-charcoal') : 'text-soft-taupe'}`}
                    >
                      {feat.label}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA */}
              {tierName === 'companion' ? (
                <button
                  disabled={isCurrent}
                  className="w-full py-3 rounded-xl border-2 border-soft-taupe text-charcoal font-semibold hover:bg-soft-taupe/20 transition-colors disabled:opacity-50"
                >
                  {isCurrent ? 'Current Plan' : 'Stay Free'}
                </button>
              ) : (
                <button
                  onClick={() => handleSelectTier(tierName)}
                  disabled={isLoading || isCurrent}
                  className={`w-full py-3 rounded-xl font-semibold transition-colors ${
                    isPopular
                      ? 'bg-warm-bronze hover:bg-deep-bronze text-white'
                      : 'bg-charcoal hover:bg-charcoal/90 text-white'
                  } disabled:opacity-50`}
                >
                  {isLoading && selectedTier === tierName ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Starting...
                    </span>
                  ) : isCurrent ? (
                    'Current Plan'
                  ) : (
                    `Start Free Trial`
                  )}
                </button>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Trust badges */}
      <div className="flex flex-wrap justify-center gap-6 text-sm text-medium-gray">
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-soft-sage" />
          7-day free trial on all paid plans
        </span>
        <span className="flex items-center gap-1.5">
          <RefreshCw className="w-4 h-4 text-calm-blue" />
          Money-back guarantee within 7 days
        </span>
        <span className="flex items-center gap-1.5">
          <X className="w-4 h-4 text-gentle-coral" />
          Cancel anytime, no questions asked
        </span>
      </div>
    </div>
  );

  if (!modal) return <div className="min-h-screen bg-warm-ivory">{content}</div>;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 bg-black/50 flex items-start justify-center overflow-y-auto py-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
      >
        <motion.div
          className="relative bg-warm-ivory rounded-3xl w-full max-w-4xl mx-4 shadow-2xl"
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 16 }}
        >
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 bg-soft-taupe/30 hover:bg-soft-taupe rounded-full flex items-center justify-center"
            >
              <X className="w-4 h-4 text-charcoal" />
            </button>
          )}
          {content}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
