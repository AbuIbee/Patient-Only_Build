import { useState } from 'react';
import { useApp } from '@/store/AppContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Heart, ArrowLeft, Check, Lock, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import type { UserRole } from '@/types';
import { TIERS, type TierName } from '@/types/subscription';

type AuthMode = 'select-role' | 'login' | 'signup' | 'choose-plan';

export default function LoginPage() {
  const { dispatch } = useApp();
  const [authMode, setAuthMode]       = useState<AuthMode>('select-role');
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [selectedTier, setSelectedTier] = useState<TierName>('companion');
  const [email, setEmail]             = useState('');
  const [password, setPassword]       = useState('');
  const [firstName, setFirstName]     = useState('');
  const [lastName, setLastName]       = useState('');
  const [isLoading, setIsLoading]     = useState(false);

  const clearForm = () => { setEmail(''); setPassword(''); setFirstName(''); setLastName(''); };

  const handleBack = () => {
    clearForm();
    if (authMode === 'choose-plan')    { setAuthMode('signup'); return; }
    if (authMode !== 'select-role')    { setAuthMode('select-role'); setSelectedRole(null); return; }
    dispatch({ type: 'SET_VIEW', payload: 'landing' });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole || !email || !password) {
      toast.error('Please enter your email and password.');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) { toast.error(error.message || 'Login failed.'); return; }

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .maybeSingle();

      if (!profile) { toast.error('Account not found.'); return; }

      dispatch({ type: 'SET_USER',          payload: { id: profile.id, email: profile.email, firstName: profile.first_name, lastName: profile.last_name, role: profile.role, createdAt: profile.created_at, updatedAt: profile.updated_at } });
      dispatch({ type: 'SET_ROLE',          payload: profile.role });
      dispatch({ type: 'SET_AUTHENTICATED', payload: true });
    } catch {
      toast.error('Unexpected error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !email || !password) {
      toast.error('Please fill in all fields.');
      return;
    }
    // Move to plan selection before creating the account
    setAuthMode('choose-plan');
  };

  const handleCompleteSignup = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { first_name: firstName, last_name: lastName, role: 'patient' },
        },
      });

      if (error) { toast.error(error.message); return; }
      if (!data.user) { toast.error('Sign-up failed. Please try again.'); return; }

      // Create profile row
      await supabase.from('profiles').upsert({
        id:         data.user.id,
        email,
        first_name: firstName,
        last_name:  lastName,
        role:       'patient',
      });

      // Create subscription row with selected tier + 7-day trial
      const trialStart = new Date();
      const trialEnd   = new Date(trialStart.getTime() + 7 * 24 * 60 * 60 * 1000);

      await supabase.from('subscriptions').upsert({
        user_id:          data.user.id,
        tier:             selectedTier,
        status:           'trialing',
        trial_started_at: trialStart.toISOString(),
        trial_ends_at:    trialEnd.toISOString(),
      }, { onConflict: 'user_id' });

      if (selectedTier === 'companion') {
        // Free tier — log them straight in
        toast.success('Welcome to MemoriaHelps! Your 7-day trial has started.');
        dispatch({ type: 'SET_USER',          payload: { id: data.user.id, email, firstName, lastName, role: 'patient', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
        dispatch({ type: 'SET_ROLE',          payload: 'patient' });
        dispatch({ type: 'SET_AUTHENTICATED', payload: true });
      } else {
        // Paid tier — redirect to Stripe Checkout
        toast.success('Account created! Taking you to checkout...');

        const tierConfig = TIERS[selectedTier];
        const { data: checkoutData, error: checkoutErr } = await supabase.functions.invoke('create-checkout-session', {
          body: {
            priceId:  tierConfig.stripePriceIdMonthly,
            tierName: selectedTier,
            userId:   data.user.id,
            email,
            trialEnd: trialEnd.toISOString(),
          },
        });

        if (checkoutErr || !checkoutData?.url) {
          // Fallback: let them in as trialing and they can pay from inside the app
          toast.error('Could not start checkout — you are on a free trial. You can upgrade from inside the app.');
          dispatch({ type: 'SET_USER',          payload: { id: data.user.id, email, firstName, lastName, role: 'patient', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() } });
          dispatch({ type: 'SET_ROLE',          payload: 'patient' });
          dispatch({ type: 'SET_AUTHENTICATED', payload: true });
        } else {
          window.location.href = checkoutData.url;
        }
      }
    } catch {
      toast.error('Unexpected error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const tierOrder: TierName[] = ['companion', 'daily_care', 'full_support'];

  return (
    <div className="min-h-screen bg-warm-ivory flex flex-col">
      <header className="bg-white border-b border-soft-taupe px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-warm-bronze rounded-xl flex items-center justify-center">
            <Heart className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-semibold text-charcoal">MemoriaHelps</span>
        </div>
        <button onClick={handleBack} className="flex items-center gap-2 text-medium-gray hover:text-charcoal transition-colors text-sm">
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      </header>

      <main className="flex-1 flex items-start justify-center px-4 py-12">
        <div className="w-full max-w-4xl">
          <AnimatePresence mode="wait">

            {/* ── Step 1: Role select ───────────────────────────────────────── */}
            {authMode === 'select-role' && (
              <motion.div key="role" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="text-center mb-8">
                  <h1 className="text-3xl font-bold text-charcoal">Welcome to MemoriaHelps</h1>
                  <p className="text-medium-gray mt-2">How are you signing in today?</p>
                </div>
                <div className="grid md:grid-cols-2 gap-4 max-w-lg mx-auto">
                  <button onClick={() => { setSelectedRole('patient'); setAuthMode('login'); }} className="p-6 bg-white rounded-2xl border-2 border-soft-taupe hover:border-warm-bronze transition-all text-left shadow-card">
                    <span className="text-3xl mb-3 block">👤</span>
                    <p className="font-semibold text-charcoal text-lg">I am the patient</p>
                    <p className="text-sm text-medium-gray mt-1">Sign in to your daily support dashboard</p>
                  </button>
                  <button onClick={() => { setSelectedRole('admin'); setAuthMode('login'); }} className="p-6 bg-white rounded-2xl border-2 border-soft-taupe hover:border-warm-bronze transition-all text-left shadow-card">
                    <span className="text-3xl mb-3 block">🛡️</span>
                    <p className="font-semibold text-charcoal text-lg">Admin / Staff</p>
                    <p className="text-sm text-medium-gray mt-1">Manage patients and accounts</p>
                  </button>
                </div>
              </motion.div>
            )}

            {/* ── Step 2: Login ─────────────────────────────────────────────── */}
            {authMode === 'login' && (
              <motion.div key="login" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="max-w-md mx-auto">
                <Card className="border-0 shadow-card">
                  <CardHeader className="text-center pb-6">
                    <CardTitle className="text-2xl font-bold text-charcoal">Sign in</CardTitle>
                    <CardDescription className="text-medium-gray">Enter your credentials to continue</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label>Email</Label>
                        <Input type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-12 rounded-xl" />
                      </div>
                      <div className="space-y-2">
                        <Label>Password</Label>
                        <Input type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="h-12 rounded-xl" />
                      </div>
                      <Button type="submit" disabled={isLoading} className="w-full h-12 bg-warm-bronze hover:bg-deep-bronze text-white rounded-xl font-medium">
                        {isLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : 'Sign In'}
                      </Button>
                    </form>
                    {selectedRole === 'patient' && (
                      <div className="mt-4 text-center">
                        <p className="text-sm text-medium-gray">
                          Don&apos;t have an account?{' '}
                          <button onClick={() => setAuthMode('signup')} className="text-warm-bronze hover:text-deep-bronze font-medium">Create one</button>
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* ── Step 3: Create account details ───────────────────────────── */}
            {authMode === 'signup' && (
              <motion.div key="signup" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="max-w-md mx-auto">
                <Card className="border-0 shadow-card">
                  <CardHeader className="text-center pb-6">
                    <CardTitle className="text-2xl font-bold text-charcoal">Create Your Account</CardTitle>
                    <CardDescription className="text-medium-gray">Step 1 of 2 — Your details</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSignUp} className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                          <Label>First Name</Label>
                          <Input placeholder="Jane" value={firstName} onChange={(e) => setFirstName(e.target.value)} className="h-11 rounded-xl" />
                        </div>
                        <div className="space-y-2">
                          <Label>Last Name</Label>
                          <Input placeholder="Smith" value={lastName} onChange={(e) => setLastName(e.target.value)} className="h-11 rounded-xl" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Email</Label>
                        <Input type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" />
                      </div>
                      <div className="space-y-2">
                        <Label>Password</Label>
                        <Input type="password" placeholder="Min 6 characters" value={password} onChange={(e) => setPassword(e.target.value)} className="h-11 rounded-xl" />
                      </div>
                      <Button type="submit" className="w-full h-12 bg-warm-bronze hover:bg-deep-bronze text-white rounded-xl font-medium">
                        Choose Your Plan →
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* ── Step 4: Choose plan ───────────────────────────────────────── */}
            {authMode === 'choose-plan' && (
              <motion.div key="plan" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold text-charcoal">Choose Your Plan</h2>
                  <p className="text-medium-gray mt-1">Step 2 of 2 — All paid plans include a free 7-day trial with a money-back guarantee.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-5 mb-8">
                  {tierOrder.map((tierName, i) => {
                    const cfg = TIERS[tierName];
                    const isSelected = selectedTier === tierName;
                    const isPopular  = tierName === 'daily_care';

                    return (
                      <motion.button
                        key={tierName}
                        initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
                        onClick={() => setSelectedTier(tierName)}
                        className={`relative text-left rounded-2xl border-2 p-5 transition-all ${isSelected ? 'border-warm-bronze bg-warm-bronze/5 shadow-elevated' : 'border-soft-taupe bg-white hover:border-warm-bronze/50'}`}
                      >
                        {isPopular && (
                          <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                            <span className="bg-warm-bronze text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                              <Star className="w-3 h-3" /> Most Popular
                            </span>
                          </div>
                        )}

                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-bold text-charcoal text-lg">{cfg.label}</p>
                            <p className="text-warm-bronze font-semibold">
                              {cfg.price === 0 ? 'Free' : `$${cfg.price}/mo`}
                            </p>
                          </div>
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${isSelected ? 'border-warm-bronze bg-warm-bronze' : 'border-soft-taupe'}`}>
                            {isSelected && <Check className="w-3 h-3 text-white" />}
                          </div>
                        </div>

                        <p className="text-sm text-medium-gray mb-3">{cfg.tagline}</p>

                        <ul className="space-y-1.5">
                          {cfg.features.filter(f => f.included).slice(0, 5).map(f => (
                            <li key={f.label} className="flex items-center gap-2 text-xs text-charcoal">
                              <Check className="w-3 h-3 text-soft-sage flex-shrink-0" />
                              {f.label}
                            </li>
                          ))}
                          {cfg.features.filter(f => !f.included).slice(0, 2).map(f => (
                            <li key={f.label} className="flex items-center gap-2 text-xs text-soft-taupe">
                              <Lock className="w-3 h-3 flex-shrink-0" />
                              {f.label}
                            </li>
                          ))}
                        </ul>
                      </motion.button>
                    );
                  })}
                </div>

                <div className="max-w-sm mx-auto">
                  <Button
                    onClick={handleCompleteSignup}
                    disabled={isLoading}
                    className="w-full h-12 bg-warm-bronze hover:bg-deep-bronze text-white rounded-xl font-semibold text-base"
                  >
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : selectedTier === 'companion' ? (
                      'Start Free — No Card Needed'
                    ) : (
                      `Start 7-Day Free Trial →`
                    )}
                  </Button>
                  {selectedTier !== 'companion' && (
                    <p className="text-xs text-center text-medium-gray mt-2">
                      You will be taken to secure checkout. Cancel anytime. Money-back guarantee within 7 days.
                    </p>
                  )}
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
